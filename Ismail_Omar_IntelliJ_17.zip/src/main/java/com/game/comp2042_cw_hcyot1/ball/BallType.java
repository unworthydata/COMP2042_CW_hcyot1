package com.game.comp2042_cw_hcyot1.ball;

/**
 * Types of Balls
 * @see RubberBall
 * @see RainbowBall
 */
public enum BallType {
    RUBBER, RAINBOW
}
