package com.game.comp2042_cw_hcyot1.brick;

/**
 * Types of Bricks
 * @see ClayBrick
 * @see SteelBrick
 * @see CementBrick
 * @see MossBrick
 */
public enum BrickType {
    CLAY, STEEL, CEMENT, MOSS
}
