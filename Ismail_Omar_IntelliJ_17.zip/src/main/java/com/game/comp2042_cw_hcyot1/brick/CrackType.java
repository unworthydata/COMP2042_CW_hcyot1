package com.game.comp2042_cw_hcyot1.brick;

/**
 * Types of cracks
 *
 * @see Crack
 */
public enum CrackType {
    LEFT, RIGHT, UP, DOWN, VERTICAL, HORIZONTAL
}
