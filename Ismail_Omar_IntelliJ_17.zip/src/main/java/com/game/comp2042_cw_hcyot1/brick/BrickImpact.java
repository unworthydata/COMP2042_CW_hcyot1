package com.game.comp2042_cw_hcyot1.brick;

public enum BrickImpact {
    UP, DOWN, LEFT, RIGHT
}
